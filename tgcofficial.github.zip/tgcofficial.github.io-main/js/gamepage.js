          var tmp = document.querySelectorAll('img.jZoIUx');
          for (var i = tmp.length - 1; i >= 0; i--) {
            tmp[i].removeAttribute("srcset");
          }
